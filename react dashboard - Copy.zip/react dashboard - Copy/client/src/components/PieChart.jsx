import { ResponsivePie } from "@nivo/pie";
import { tokens } from "../theme";
import { useTheme } from "@mui/material";
import { mockPieData as data } from "../data/mockData";
import { PieChart, Pie, Legend, Tooltip,ResponsiveContainer } from "recharts";
import { useState } from "react";
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}

const PieCharts = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);


  
  return (
    <ResponsiveContainer width="100%" >
    <PieChart>
    
      <Pie
        dataKey="NoOfParts"
        data={props.data}
        cx="50%"
        cy="50%"
        innerRadius={40}
        outerRadius={80}
        fill="#82ca9d"
      />
      
      <Tooltip/>
    </PieChart>
    </ResponsiveContainer>
   
  
    
  );
};

export default PieCharts;
