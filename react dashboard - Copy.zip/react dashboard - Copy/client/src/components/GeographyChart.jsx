import { useTheme } from "@mui/material";
import { ResponsiveChoropleth } from "@nivo/geo";
import { geoFeatures } from "../data/mockGeoFeatures";
import { tokens } from "../theme";
import { useEffect, useState } from "react";
import { getmap } from "../services/api";
import { WorldMap } from "react-svg-worldmap"
// import { mockGeographyData as data } from "../data/mockData";

const GeographyChart = ({ isDashboard = false }) => {
   data=0
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <div className="App" >
       <WorldMap 
       backgroundColor={colors} 
       borderColor="#ffff00"
       features={geoFeatures.features}
       color="red" title="" value-suffix="sales" size="xl" data={data} />
    </div>
  );
};

export default GeographyChart;
