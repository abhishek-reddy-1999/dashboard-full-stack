import express from "express"
import cros from "cors"
import sql from "mssql"
import bodyParser from "body-parser"
import router from './routes/route.js'

import cookieParser from "cookie-parser"
const app = express()
const port = process.env.port || 4000
app.use(bodyParser.json({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));
const corsOptions = {
  origin: "http://localhost:3000",
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true,
 
};
app.use(cookieParser())
app.use(cros(corsOptions));


app.use('/',router)

app.listen(4000, '192.168.24.116', () => {
  console.log('Server started at http://192.168.24.116:' + port + '')
});
