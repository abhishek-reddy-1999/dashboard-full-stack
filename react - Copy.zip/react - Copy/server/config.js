 module.exports = {
 secretKey: "Shashangka Shekhar",
 algorithm: 'HS256', //default: HS256
 };