import express from 'express'
import {getcumulative,getdatewise,getday,getfinance,getinit,getmachine,getpart,getprocces,getmonth,getweek,getupto, auth} from "../controller/controler.js"


const router=express.Router()

router.get('/bar',getinit);
router.post('/date',getdatewise)
router.post('/day',getday)
router.post('/month',getmonth)
router.get('/year',getweek)
router.get('/finace',getfinance)
router.post('/upto',getupto)
router.get('/part',getpart)
router.get('/proces',getprocces)
router.get('/machine',getmachine)
router.post('/cumulative',getcumulative)
router.post('/login',auth)









export default router


