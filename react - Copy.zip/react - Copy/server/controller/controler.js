import sql from "mssql"
import jwt from "jsonwebtoken"
import bcrypt from "bcrypt-nodejs"
import cookieParser from "cookie-parser"
import dotenv from"dotenv"
dotenv.config(); 
export const getinit=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "WAXTran",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "select Sum(NoOfParts) as value ,PartNo as label,partNo as link from WAXTran..Invoice where InvoiceDate between '2019-01-02' and '2019-01-07' group by PartNo",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });

    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getdatewise=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "WAXTran",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          var dates = {
            fromdate: req.body["fromdate"],
            todate: req.body["todate"],
          };
          console.log(req.body)
          var fromdate = dates.fromdate;
          var todate = dates.todate;
        
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error connecting to db");
            }
            else {
              let request = new sql.Request();
              request.query(
                "select Sum(NoOfParts) as value ,PartNo as label, PartNo as link  from WAXTran..Invoice where InvoiceDate between '" + fromdate + "' and '" + todate + "' group by PartNo  ",
                function (err, data) {
                  if (err) {
                    console.log("error data retrive", err);
                  }
                  else {
                    res.send(data.recordset);
                    // console.log(data.recordset);
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getday=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "WAXTran",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
        const month ={
         b: req.body['month'],
         f: req.body['from'],
        g:req.body['to']
        }
        const b=month.b
        const f=month.f
        const g=month.g
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
               `Select convert(varchar(10),P.ProdDate, 120) As label,
               Sum(P.Oee)/COUNT(P.Oee) As value
               From QMSTRAN..Gen_Production P Left Join QMSMast..Gen_Part M On M.PartName =P.Part
               where P.ProdDate Between '${f}' And '${g}' 
               And DATENAME(month, ProdDate)='${b}'
               Group By P.ProdDate Order By P.ProdDate
             `,
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    // console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getmonth=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          var dates = {
            f: req.body["f"],
            g: req.body["g"]
        
          };
          // console.log(req.body)
          const f = dates.f
          const g = dates.g
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              var qurr=`Select X.label,SUM(value)/SUM(A) As value,
              (Case
              When X.label ='April' Then 1
              When X.label ='May' Then 2
              When X.label ='June' Then 3
              When X.label ='July' Then 4
              When X.label ='August' Then 5
              When X.label ='September' Then 6
              When X.label ='October' Then 7
              When X.label ='November' Then 8
              When X.label ='December' Then 9
              When X.label ='January' Then 10
              When X.label ='February' Then 11
              When X.label ='March' Then 12
              End) As MnthOrd From (
              Select DATENAME(month, P.ProdDate) As label,
              P.Oee As value,A1.A
              From QMSTRAN..Gen_Production P Left Join QMSMast..Gen_Part M On M.PartName =P.Part
              Left Join (Select Prodid,COUNT(ProdDate) As A From QMSTRAN..Gen_Production P Left Join QMSMast..Gen_Part M On M.PartName =P.Part Where isnull(Oee,0)>0 And ProdDate Between '${f}' And '${g}'
              Group By Prodid) As A1 On A1.Prodid=P.Prodid
              Where isnull(P.Oee,0)>0 And P.ProdDate Between '${f}' And '${g}'
              ) As X
              Group By X.label
              Order By MnthOrd
            `;
        
              request.query( qurr,
                (err, data) => {
                if (err) {
                  console.log("Error in query", err);
                } else {
                  res.send(data.recordset);
                  //  console.log(data.recordset)
                }
              }
              );
        }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getweek=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "WAXTran",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "select Sum(NoOfParts) as value ,PartNo as label,partNo as link from WAXTran..Invoice where InvoiceDate between '2019-01-02' and '2019-01-07' group by PartNo",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getfinance=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "Select Finyear from QMSMast..Financial order by Fromdate Desc",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }



}
export const getupto=async(req,res)=>{
    try{
        const config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          var dates = {
            fin: req.body["fin"],
        
          };
          // console.log(req.body)
          const year = dates.fin
          // const fin=finance.fin
          //  console.log(year)
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                " Select convert(varchar(10), Fromdate, 120) fromdate, convert(varchar(10), Todate, 120) as todate from QMSMast..Financial Where FinYear ='" + year + "'",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }

}
export const getpart=async(req,res)=>{
    try{
        var config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "select Distinct Isnull(ParentPart,'') As Part from QMSMast..Gen_Part",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    // console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }

}
export const getprocces=async(req,res)=>{
    try{
        var config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "select PartName   from QMSMast..Gen_Part  Order By PartName",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }

}
export const getmachine=async(req,res)=>{
    try{
        var config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "Select McName From QMSMast..Gen_Machines Order by McName",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    //  console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }

}
export const getcumulative=async(req,res)=>{
    try{
        var config = {
            user: "sa",
            password: "indotpt@2016",
            server: "IMTPT-IT-D03",
            database: "QMSMast",
        
            options: {
              trustedconnection: true,
              enableArithAbrot: true,
              trustServerCertificate: true,
              instancename: "",
        
            },
            port: 1433,
          };
          var dates = {
            a: req.body["a"],
            b: req.body["b"],
            c: req.body["c"],
            d: req.body["d"],
            e: req.body["e"],
            f: req.body["f"],
            g: req.body["g"],
          };
        
          var a = dates.a;
          var b = dates.b;
          var c = dates.c;
          var d = dates.d;
          var e = dates.e;
          var f = dates.f;
          var g = dates.g;
        
        
          sql.connect(config, (err) => {
            if (err) {
              console.log("error in connection", err);
            } else {
              var request = new sql.Request();
              request.query(
                "Select  convert(varchar(10), P.ProdDate, 120)  As label, Sum(P.Oee)/COUNT(P.Oee) As value From QMSTRAN..Gen_Production P Left Join QMSMast..Gen_Part M On M.PartName =P.Part where P.ProdDate Between '" + f + "' And '" + g + "' And DATENAME(month, ProdDate)='" + b + "' Group By P.ProdDate Order By P.ProdDate",
                (err, data) => {
                  if (err) {
                    console.log("Error in query", err);
                  } else {
                    res.send(data.recordset);
                    // console.log(data.recordset)
                  }
                }
              );
            }
          });
    }
    catch(e){
        res.status(404).json({massage:e.massage})

    }

}
export const auth=async(req,res)=>{
  try{
    var config = {
      user: "sa",
      password: "indotpt@2016",
      server: "IMTPT-IT-D03",
      database: "invoicetmp",
  
      options: {
        trustedconnection: true,
        enableArithAbrot: true,
        trustServerCertificate: true,
        instancename: "",
  
      },
      port: 1433,
    };
    // console.log(req.body)
   
    sql.connect(config, (err) => {
      if (err) {
        console.log("error in connection", err);
      } else {
        var request = new sql.Request();
        request.query(
         `select * from invoicetmp..login where role='${req.body['username']} 'and password='${req.body['password']}' `,
          (err, data) => {
            if (err) {
              console.log("Error in query", err);
            }
           const era=data.recordset
        
            if(era.length>0){
              const Name=era[0].role
              const accessToken = jwt.sign({ 
                Name
            }, process.env.ACCESS_TOKEN_SECRET, { 
                expiresIn: '10m'
            });
            const refreshToken = jwt.sign({ 
              Name 
          }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '1d' });  
          res.cookie('jwt', refreshToken, { httpOnly: true,  
            sameSite: 'None', secure: true,  
            maxAge: 24 * 60 * 60 * 1000 }); 
            res.cookie({ accessToken }); 
             return(
         
              res.json({message:"success"})
             )
            }
            else{
              return(
                res.json({message:"failed"})
               )
            }
          }
        );
      }
    });



  }catch(e){
    res.status(404).json({massage:e.massage})
  }
}