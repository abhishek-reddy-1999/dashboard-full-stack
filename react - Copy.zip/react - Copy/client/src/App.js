import { useState } from "react";
import { Routes, Route,useNavigate } from "react-router-dom";
import Topbar from "./scenes/global/Topbar";
import Sidebar from "./scenes/global/Sidebar";
import Dashboard from "./scenes/dashboard";
import Pie from "./scenes/pie";
import Geography from "./scenes/geography";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { ColorModeContext, useMode } from "./theme";
import Calendar from "./scenes/calendar/calendar";
import BarChart from "./components/BarChart";
import Person from "./scenes/person/Person";
import Bar from "./scenes/bar";
import Marketing from "./scenes/sales/Marketing";
import Sales from "./scenes/sales/Sales";
import React from "react";
import Admin from "./scenes/sales/Admin";
import Adminmc from "./scenes/sales/AdminMc";
import Cummins from "./scenes/sales/Cummins";
import Fetling from "./scenes/sales/Fetling";
import General from "./scenes/sales/General";
import Isp from "./scenes/sales/Isp";
import Lab from "./scenes/sales/Lab";
import Machineshop from "./scenes/sales/MachineshopG";
import Maintanace from "./scenes/sales/Maintanace";
import ManufaturingLab from "./scenes/sales/ManufacrurialLab";
import Melting from "./scenes/sales/Melting";
import Nozelring from "./scenes/sales/Nozelring";
import Quality from "./scenes/sales/Quality";
import Shellroom from "./scenes/sales/Shellrom";
import Toolrom from "./scenes/sales/Toolrom";
import Utility from "./scenes/sales/Utility";
import UtilityMc from "./scenes/sales/UtilityMc";
import WaxInjection from "./scenes/sales/Wax injection";
import Dispatch from "./scenes/sales/dispatch";
import Fourth from "./scenes/sales/Fourth";
import Rmyard from "./scenes/sales/Rmyard";
import Vacume from "./scenes/sales/Vacume";
import { tokens } from "./theme";
import { Box, Button, TextField, Typography, useTheme } from "@mui/material";
import { login } from "./services/api";
import axios from "axios";






function App() {
  axios.defaults.withCredentials=true
  const [theme, colorMode] = useMode();
  const [isSidebar, setIsSidebar] = useState(false);
  const [auth, setauth] = useState(false);
  const colors = tokens(theme.palette.mode);
  const [user, setuser] = useState({
    username: "",
    password: "",
  });
  const navigate=useNavigate()
  
  function setup(e) {
    setuser({ ...user, [e.target.name]: e.target.value });
  }

  // console.log(user)
  const mana=user
  axios.defaults.withCredentials=true
const loginghadler=async(e)=>{
  e.preventDefault();
  const response=await login(mana);
  const data=response.data
 
console.log(data)
  if(response.data.message ==="success"){
    alert("login success");
    setauth(true);
    navigate('/');
  }
  else{
    alert('username or passowrd is incorrect')
  }
}
  

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div className="app">
          {auth ? (
             <>
             <Sidebar isSidebar={isSidebar} />
             <main className="content">
               <Topbar setIsSidebar={setIsSidebar} />
               
               <Routes>
               
                 <Route path="/person" element={<Person></Person>} />
                 <Route path="/" element={<Dashboard />} />
                 <Route path="/bar" element={<Bar />} />
                 <Route path="/dispatch" element={<Dispatch />} />
                 <Route path="/pie" element={<Pie />} />
                 <Route path="/calender" element={<Calendar />} />
                 <Route path="/geography" element={<Geography />} />
                 <Route path="/sales" element={<Sales />} />
                 <Route path="/Marketing" element={<Marketing />} />
                 <Route path="/admin" element={<Admin />} />
                 <Route path="/adminmc" element={<Adminmc />} />
                 <Route path="/cummins" element={<Cummins />} />
                 <Route path="/fetling" element={<Fetling />} />
                 <Route path="/general" element={<General />} />
                 <Route path="/isp" element={<Isp />} />
                 <Route path="/lab" element={<Lab />} />
                 <Route path="/MachineshopG" element={<Machineshop />} />
                 <Route path="/Maintanace" element={<Maintanace />} />
                 <Route path="/ManufaturingLab" element={<ManufaturingLab />} />
                 <Route path="/melting" element={<Melting />} />
                 <Route path="/Nozelring" element={<Nozelring />} />
                 <Route path="/quality" element={<Quality />} />
                 <Route path="/shellroom" element={<Shellroom />} />
                 <Route path="/toolrom" element={<Toolrom />} />
                 <Route path="/utility" element={<Utility />} />
                 <Route path="/utilitymc" element={<UtilityMc />} />
                 <Route path="/wax" element={<WaxInjection />} />
                 <Route path="/axis" element={<Fourth />} />
                 <Route path="/yard" element={<Rmyard />} />
                 <Route path="/meltingv" element={<Vacume />} />
               </Routes>
             </main>
             </>
          ):(
            
            <Box p="50px"
    display='flex'
    justifyContent='center'
    alignContent='center'
    sx={{ml:"35%",mt:'10%'}}
    >
      <Box
        backgroundColor={colors.primary[400]}
        height="300px"
        width="350px"
       
        borderRadius="10px"
        display="flex"
        justifyContent="center"
        alignContent='center'
        
      >
        <Box>
          <center>
            <Typography variant="h2">Login</Typography>
          </center>
          <Box py='10px' >
           <Typography>username</Typography>
            <TextField
              type="text"
              placeholder="username"
              required
              width="50%"
              name="username"
              sx={{ width: "100%" }}
              onChange={(e)=>setup(e)}
              autoComplete="off"
            ></TextField>
          </Box>
          <Box justifyContent="center" alignContent="center">
           <Typography>Password</Typography>
            <TextField
              htmlFor="outlined-adornment-password"
              type="password"
              placeholder="password"
              required
              name="password"
              sx={{ width: "100%" }}
              onChange={(e)=>setup(e)}
              autoComplete="off"
            ></TextField>
          </Box>
          <Box py='10px'>
            <center>
              <Button variant="contained" color="primary" type="submit" onClick={(e)=>loginghadler(e)} >
                Submit
              </Button>
            </center>
          </Box>
        </Box>
      </Box>
    </Box>


            // <Routes>
            //   <Route path="/login" element={<Login></Login>} />
            // </Routes>
          )}
       
        </div>
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;
