import { useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../theme";
import { useRef } from "react";
import {
  BarChart,
  Bar,
  Brush,
  ReferenceLine,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  
  ResponsiveContainer
} from "recharts";

import axios from "axios";
axios.defaults.withCredentials=true



const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}



const Bars = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
 const data=props.data
// const data=useRef(props.data)
// const dara=data.current()
  return (
    <>
     
       
    <ResponsiveContainer width="100%" height="100%">
      
      <BarChart
      width={500}
      height={350}
      data={data}
      margin={{
        top: 5,
        right: 30,
        left: 20,
        bottom: 5
      }}
    >
      
      <XAxis dataKey='label' />
      <YAxis />
      <Tooltip content={<CustomTooltip /> } wrapperStyle={{ width: 100, backgroundColor: `${colors.primary[400]}` }}  />
      <Legend verticalAlign="bottom"  wrapperStyle={{ lineHeight: "60px" }} />
      <Bar dataKey="value" fill="#615cbf"  />
      <ReferenceLine y={6000} stroke="#f5425d" />
      <Brush dataKey="" height={30} stroke="#8884d8" />
      <ReferenceLine y={6000} stroke="#f5425d" />
      <ReferenceLine y={80} stroke="#f5425d" />
    </BarChart>
      </ResponsiveContainer>
      </>
  );
};

export default Bars;
