import { Box, Button, TextField, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import { tokens } from "../theme";
function Login() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [user, setuser] = useState({
    username: "",
    password: "",
  });
  function setup(e) {
    setuser({ ...user, [e.target.name]: e.target.value });
  }

  return (
    <Box p="50px"
    display='flex'
    justifyContent='center'
    alignContent='center'
    sx={{ml:"35%",mt:'10%'}}
    >
      <Box
        backgroundColor={colors.primary[400]}
        height="300px"
        width="350px"
       
        borderRadius="10px"
        display="flex"
        justifyContent="center"
        alignContent='center'
        
      >
        <Box>
          <center>
            <Typography variant="h2">Login</Typography>
          </center>
          <Box py='10px' >
           <Typography>username</Typography>
            <TextField
              type="text"
              placeholder="username"
              required
              width="50%"
              name="username"
              sx={{ width: "100%" }}
              onChange={(e)=>setup(e)}
              autoComplete="off"
            ></TextField>
          </Box>
          <Box justifyContent="center" alignContent="center">
           <Typography>Password</Typography>
            <TextField
              htmlFor="outlined-adornment-password"
              type="password"
              placeholder="password"
              required
              name="password"
              sx={{ width: "100%" }}
              onChange={(e)=>setup(e)}
              autoComplete="off"
            ></TextField>
          </Box>
          <Box py='10px'>
            <center>
              <Button variant="contained" color="primary" type="submit">
                Submit
              </Button>
            </center>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export default Login;
