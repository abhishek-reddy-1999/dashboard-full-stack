import React from "react";
import { tokens } from "../theme";
import { useTheme } from "@mui/material";
import { mockPieData as data } from "../data/mockData";
import { PieChart, Pie, Legend, Tooltip,ResponsiveContainer } from "recharts";
import { useState } from "react";
import axios from "axios";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}

const PieCharts = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  axios.defaults.withCredentials=true

  
  return (
    <ResponsiveContainer width="100%" >
    <PieChart>
    
      <Pie
        dataKey="value"
        data={props.data}
        cx="50%"
        cy="50%"
        innerRadius={40}
        outerRadius={80}
        fill="#82ca9d"
      />
      
    <Tooltip content={<CustomTooltip />}   wrapperStyle={{ width: 100, backgroundColor: '#5e5b5e' }}/>
    </PieChart>
    </ResponsiveContainer>
   
  
    
  );
};

export default PieCharts;
