import React from "react";
import { tokens } from "../theme";
import { useTheme } from "@mui/material";
import { mockPieData as data } from "../data/mockData";
import { PieChart, Pie, Legend, Tooltip,ResponsiveContainer } from "recharts";
import { useState } from "react";
import axios from "axios";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="name">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}
axios.defaults.withCredentials=true
const PieCharts = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);


  
  return (
    <ResponsiveContainer width="100%" >
    <PieChart>
    
    <Pie
        dataKey="value"
        isAnimationActive={false}
        data={props.data}
        cx="50%"
        cy="50%"
        outerRadius={80}
        fill="#8884d8"
        label
      />
      
    <Tooltip content={<CustomTooltip />}   wrapperStyle={{ width: 100, backgroundColor: '#5e5b5e' }}/>
    </PieChart>
    </ResponsiveContainer>
   
  
    
  );
};

export default PieCharts;
