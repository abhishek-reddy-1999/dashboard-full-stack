import * as React from 'react';
import { useState, useEffect } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
import { Link, redirect } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { styled} from '@mui/material/styles';
import { tokens } from "../../theme";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import Bar from '../bar';
import { useHistory } from "react-router-dom";
import { useNavigate } from 'react-router-dom';
import {GiBoltCutter,GiMeltingIceCube,GiNautilusShell,GiVendingMachine,GiGraveyard,GiPizzaCutter,GiSoapExperiment,GiSewingMachine,GiMeltingMetal,GiMetalBar,GiWaxSeal} from "react-icons/gi"
import {SiQualcomm,SiShelly,SiGeneralmotors} from "react-icons/si"
import {FaToolbox} from "react-icons/fa"
import {BiSolidTruck,BiMoneyWithdraw} from "react-icons/bi"
import {GrUserAdmin} from "react-icons/gr"
import {LuUtilityPole,LuAxis3D} from "react-icons/lu"
import { MdEngineering,MdAdminPanelSettings,MdAttachMoney } from "react-icons/md";
import {
  FcMindMap,
  FcBullish,
  FcPieChart,
  FcHome,
  FcInTransit,
  FcSalesPerformance,
  FcMoneyTransfer,FcSteam
} from "react-icons/fc";

import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import { TreeView } from "@mui/x-tree-view/TreeView";
import { TreeItem ,treeItemClasses } from "@mui/x-tree-view/TreeItem";

const Item = ({ title, to, icon, selected, setSelected }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  
  return (
    <MenuItem
      active={selected === title}
      style={{
        color: colors.grey[100],
      }}
      onClick={() => setSelected(title)}
      icon={icon}
    >
      <Typography>{title}</Typography>
      <Link to={to} />
    </MenuItem>
  );
};
const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
  color: theme.palette.text.secondary,
  [`& .${treeItemClasses.content}`]: {
    color: theme.palette.text.secondary,
    borderTopRightRadius: theme.spacing(2),
    borderBottomRightRadius: theme.spacing(2),
    paddingRight: theme.spacing(1),
    fontWeight: theme.typography.fontWeightMedium,
    '&.Mui-expanded': {
      fontWeight: theme.typography.fontWeightRegular,
    },
    '&:hover': {
      backgroundColor: theme.palette.action.hover,
    },
    '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
      backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
      color: 'var(--tree-view-color)',
    },
    [`& .${treeItemClasses.label}`]: {
      fontWeight: 'inherit',
      color: 'inherit',
    },
  },
  [`& .${treeItemClasses.group}`]: {
    marginLeft: 4,
    [`& .${treeItemClasses.content}`]: {
      paddingLeft: theme.spacing(4),
    },
  },
}));

const StyledTreeItem = React.forwardRef(function StyledTreeItem(props, ref,title, to, icon, selected, setSelected) {
  const theme = useTheme();
  const {
    bgColor,
    color,
    labelIcon: LabelIcon,
    labelInfo,
    labelText,
    colorForDarkMode,
    bgColorForDarkMode,
    ...other
  } = props;

  const styleProps = {
    '--tree-view-color': theme.palette.mode !== 'dark' ? color : colorForDarkMode,
    '--tree-view-bg-color':
      theme.palette.mode !== 'dark' ? bgColor : bgColorForDarkMode,
  };

  return (
    <StyledTreeItemRoot
      label={
        <Box
          sx={{
            display: 'flex',
            alignItems: "center",
            p: 2,
            pr: 0,
          }}
        >
          <Link to={to} />
          <Box component={LabelIcon} color="inherit" sx={{ mr: 1 }}  />
          <Typography variant="body2" sx={{ fontWeight: 'inherit', flexGrow: 1 }}>
            {labelText}  <Link to={to} />
          </Typography>
          <Typography variant="caption" color="inherit">
            {labelInfo}  <Link to={to} />
          </Typography>
        </Box>
      }
      style={styleProps}
      {...other}
      ref={ref}
    />
  );
});

const Sidebar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [selected, setSelected] = useState("Dashboard");
  const navigate = useNavigate();


  return (
    <Box
      sx={{
        "& .pro-sidebar-inner": {
          background: `${colors.primary[400]} !important`,
        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "5px 35px 5px 20px !important",
        },
        "& .pro-inner-item:hover": {
          color: "#868dfb !important",
        },
        "& .pro-menu-item.active": {
          color: "#6870fa !important",
        },
      }}
    >
      <ProSidebar collapsed={isCollapsed}>
        <Menu iconShape="square">
          <MenuItem
            onClick={() => setIsCollapsed(!isCollapsed)}
            icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
            style={{
              margin: "10px 0 20px 0",
              color: colors.grey[100],
            }}
          >
            {!isCollapsed && (
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
              >
                <Typography variant="h3" color={colors.grey[100]}>
                  Employee
                </Typography>
                <IconButton onClick={() => setIsCollapsed(!isCollapsed)}>
                  <MenuOutlinedIcon />
                </IconButton>
              </Box>
            )}
          </MenuItem>

          {!isCollapsed && (
            <Box mb="25px">
              <Box display="flex" justifyContent="center" alignItems="center">
                <img
                  alt="profile-user"
                  width="100px"
                  height="100px"
                  src={`../../assets/1637664066687.jfif`}
                  style={{ cursor: "pointer", borderRadius: "50%" }}
                />
              </Box>
              <Box textAlign="center">
                <Typography
                  variant="h2"
                  color={colors.grey[100]}
                  fontWeight="bold"
                  sx={{ m: "10px 0 0 0" }}
                >
                  INDO MIM
                </Typography>
                <Typography variant="h5" color={colors.greenAccent[500]}>
                  Plant Admin Dashboard
                </Typography>
              </Box>
            </Box>
          )}

          <Box
            paddingLeft={isCollapsed ? undefined : "10%"}
            sx={{ height: "500px" }}
          >
            <Item
              title="Home"
              to="/"
              icon={<FcHome />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Barchat"
              to="/bar"
              icon={<FcBullish />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Piechart"
              to="/pie"
              icon={<FcPieChart />}
              selected={selected}
              setSelected={setSelected}
            />

            {/* <Item
              title="Departments"
              to="/department"
              icon={<FcMindMap/>}
              selected={selected}
              setSelected={setSelected}
              
            /> */}

            <TreeView
              aria-label="Department"
              // defaultCollapseIcon={<ExpandMoreIcon />}
              // defaultExpandIcon={<ChevronRightIcon />}
              defaultExpanded={["3"]}
              defaultEndIcon={<div style={{ width: 24 }} />}
              sx={{
                height: 264,
                flexGrow: 1,
                maxWidth: 400,
                overflowY: "auto",
              }}
              justifyContent="center"
        
            >
              <StyledTreeItem nodeId="1" label="department Wise" icon={<FcMindMap/>}>
                <StyledTreeItem
                  nodeId="2"
                  label="Dispactch"
                  icon={<BiSolidTruck />}
                  onClick={(e)=>{navigate('/dispatch')}}
                >
                </StyledTreeItem>
                <StyledTreeItem nodeId="24" label="sales" icon={<MdAttachMoney/>} onClick={(e)=>{navigate('/sales')}}></StyledTreeItem>
                  <StyledTreeItem nodeId="30" label="Marketing" icon={<BiMoneyWithdraw/>} onClick={(e)=>{navigate('/Marketing')}}></StyledTreeItem>
                <TreeItem nodeId="3" label="FETTLING" icon={<GiBoltCutter/>} onClick={(e)=>{navigate('/fetling')}}></TreeItem>
                <TreeItem nodeId="4" label="ISP" icon={<GiPizzaCutter/>} onClick={(e)=>{navigate('/isp')}}></TreeItem>
                <TreeItem nodeId="5" label="LAB" icon={<GiSoapExperiment/>} onClick={(e)=>{navigate('/lab')}}></TreeItem>
                <TreeItem nodeId="6" label="MACHINE SHOP - GENERAL" icon={<GiSewingMachine/>} onClick={(e)=>{navigate('/MachineshopG')}}></TreeItem>
                <TreeItem nodeId="7" label="MELTING" icon={<GiMeltingMetal/>} onClick={(e)=>{navigate('/melting')}}></TreeItem>
                <TreeItem nodeId="8" label="METALURGICAL LAB" icon={<GiMetalBar/>} onClick={(e)=>{navigate('/ManufaturingLab')}}></TreeItem>
                <TreeItem nodeId="9" label="QUALITY" icon={<SiQualcomm/>} onClick={(e)=>{navigate('/quality')}}></TreeItem>
                <TreeItem nodeId="10" label="SHELL ROOM" icon={<SiShelly/>} onClick={(e)=>{navigate('/shellroom')}}></TreeItem>
                <TreeItem nodeId="11" label="TOOL ROOM" icon={<FaToolbox/>} onClick={(e)=>{navigate('/toolrom')}}></TreeItem>
                <TreeItem nodeId="12" label="UTILITY" icon={<LuUtilityPole/>} onClick={(e)=>{navigate('/utility')}}></TreeItem>
                <TreeItem nodeId="13" label="WAX INJECTION" icon={<GiWaxSeal/>} onClick={(e)=>{navigate('/wax')}}></TreeItem>
                <TreeItem nodeId="14" label="GENERAL" icon={<SiGeneralmotors/>} onClick={(e)=>{navigate('/general')}}></TreeItem>
                <TreeItem
                  nodeId="15"
                  label="MACHINE SHOP - NOZZLE RING" icon={<FcSteam/>} onClick={(e)=>{navigate('/Nozelring')}}
                ></TreeItem>
                <TreeItem nodeId="16" label="MACHINE SHOP - CUMMINS" icon={<GiVendingMachine/>} onClick={(e)=>{navigate('/cummins')}}></TreeItem>
                <TreeItem nodeId="17" label="MAINTENANCE" icon={<MdEngineering/>} onClick={(e)=>{navigate('/maintanace')}}></TreeItem>
                <TreeItem nodeId="18" label="ADMIN" icon={<MdAdminPanelSettings/>} onClick={(e)=>{navigate('/admin')}}></TreeItem>
                <TreeItem nodeId="19" label="4TH AXIS" icon={<LuAxis3D/>} onClick={(e)=>{navigate('/axis')}}></TreeItem>
                <TreeItem nodeId="20" label="RM YARD" icon={<GiGraveyard/>} onClick={(e)=>{navigate('/yard')}}></TreeItem>
                <TreeItem nodeId="21" label="VACUUM MELTING" icon={<GiMeltingIceCube/>} onClick={(e)=>{navigate('/meltingv')}}></TreeItem>
                <TreeItem nodeId="22" label="ADMIN MC" icon={<GrUserAdmin/>} onClick={(e)=>{navigate('/adminmc')}}></TreeItem>
                <TreeItem nodeId="23" label="UTILITY MC" icon={<GiNautilusShell/>} onClick={(e)=>{navigate('/utilitymc')}}></TreeItem>
              </StyledTreeItem>
            </TreeView>
          </Box>
        </Menu>
      </ProSidebar>
    </Box>
  );
};

export default Sidebar;
