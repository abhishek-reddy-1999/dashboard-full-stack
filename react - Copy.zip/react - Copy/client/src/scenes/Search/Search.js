import React from 'react'
import { Box,TextField,Button } from '@mui/material'
import { useTheme } from "@mui/material";
import { tokens } from "../../theme";
import { useState } from 'react';
import { datewise } from '../../services/api';



const Search= () =>{

    const theme = useTheme();
    const colors = tokens(theme.palette.mode);

    const [fromdate,setfromdate]=useState("");
    const[todate,settodate]=useState("");
    const [Bardata,setdata]=useState([]);




    function fromset(e){
      setfromdate(e.target.value);
    
    }
    function fromto(e){
      settodate(e.target.value);
    
    }
    function setnull(){
      setfromdate("") ;
      settodate("")
    }
    
   const dates={
    fromdate,
    todate
   }
    
    const binddata = async()=>{
     const response=await datewise(dates)
     setdata(response.data)
    }
   
  
  return (
    
    
      <Box>
          <Box sx={{mb:"10px"}}
          display="flex"
          justifyContent="space-evenly"
          >
            <TextField id="outlined-basic" label="" variant="outlined" type="date" sx={{mb:'10px',width:'200px',pr:"10px"}} onChange={(e)=>fromset(e)} value={fromdate} />
            <TextField id="outlined-basic" label="" variant="outlined" type="date" sx={{mb:"10px",width:'200px',pr:"10px"}} onChange={(e)=>fromto(e)} value={todate }  />
            <center>
             <Button variant="contained" color="success" sx={{mb:"10px", mr:"10px",mt:"10px"}} onClick={binddata} >Search</Button>
             <Button variant="contained" color="success" sx={{mb:"10px", mr:"10px",mt:"10px"}} type="reset" onClick={setnull}>Reset</Button>
            </center>
          </Box>

        </Box>
       
  )
}




export default Search




