import React from "react";
import {
  Box,
  Button,
  IconButton,
  Input,
  Typography,
  useTheme,
  TextField,
  ButtonGroup,
} from "@mui/material";
import { tokens } from "../../theme";

import LineCharts from "../../components/LineChart";

import BarChart from "../../components/BarChart";

import PieCharts from "../../components/PieCharts";
import { useState, useEffect } from "react";

import { datewise, getstack } from "../../services/api";

import { getbar } from "../../services/api";
const Machineshop = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [fromdate, setfromdate] = useState("");
  const [todate, settodate] = useState("");
  const [Bardata, setdata] = useState([]);

  function fromset(e) {
    setfromdate(e.target.value);
  }
  function fromto(e) {
    settodate(e.target.value);
  }
  function setnull() {
    setfromdate("");
    settodate("");
  }

  let dates = {
    fromdate,
    todate,
  };

  const binddata = async () => {
    try{
      const response = await datewise(dates);
      setdata(response.data);
      console.log(response.data);
    }catch(e){
        console.log(e)
    }
    
  };
  useEffect(() => {
    fetchUserData();
  }, []);
  const fetchUserData = async () => {
    
      try{
        const response = await getbar();
        setdata(response.data);
        // console.log(response.data)
      }catch (e){
        console.log(e)
      }
   
  };
  
  return (
    <>
   <Box>
      <center><Typography variant="h1">Machineshop report</Typography></center>
    </Box>
    <Box m="20px">
    
      <Box>
        <Box sx={{ mb: "10px" }} display="flex" justifyContent="space-evenly">
          <TextField
            id="outlined-basic"
            label=""
            variant="outlined"
            type="date"
            sx={{ mb: "10px", width: "200px", pr: "10px" }}
            onChange={(e) => fromset(e)}
            value={fromdate}
          />
          <TextField
            id="outlined-basic"
            label=""
            variant="outlined"
            type="date"
            sx={{ mb: "10px", width: "200px", pr: "10px" }}
            onChange={(e) => fromto(e)}
            value={todate}
          />
          <center>
            <Button
              variant="contained"
              color="success"
              sx={{ mb: "10px", mr: "10px", mt: "10px" }}
              onClick={binddata}
            >
              Search
            </Button>
            <Button
              variant="contained"
              color="success"
              sx={{ mb: "10px", mr: "10px", mt: "10px" }}
              type="reset"
              onClick={setnull}
            >
              Reset
            </Button>
          </center>
        </Box>
      </Box>

      <Box
        gridColumn="span 12"
        gridRow="span 4"
        backgroundColor={colors.primary[400]}
      >
        
        <Box height="300px" mt="10px">
        <Typography variant="h5" fontWeight="600" mt={"-10px"}>
              <center>Sales report</center>
            </Typography>
          <BarChart data={Bardata}  isDashboard={true} />
          {/* <FusionBar data={Bardata}></FusionBar> */}
        </Box>
      </Box>

      <Box
        display="grid"
        gridTemplateColumns="repeat(12, 1fr)"
        gridAutoRows="140px"
        gap="20px"
        sx={{ mt: "10px" }}
      >
        {/* ROW 1 */}
        <Box
          gridColumn="span 6"
          gridRow="span 2"
          backgroundColor={colors.primary[400]}
          p="10px"
        >
          <Typography variant="h5" fontWeight="600" margin={"5px"}>
              <center>Piecharts</center>
            </Typography>
        <PieCharts data={Bardata}></PieCharts>

        </Box>
        <Box
          gridColumn="span 6"
          gridRow="span 2"
          backgroundColor={colors.primary[400]}
          p="30px"
        >
          <center>
            <Typography variant="h5" fontWeight="600" margin={"5px"}>
              Linechart
            </Typography>
          </center>
          <LineCharts data={Bardata}></LineCharts>
        </Box>
      </Box>

      <Box
        gridColumn="span 12"
        gridRow="span 6"
        backgroundColor={colors.primary[400]}
        padding="30px"
        mt="10px"
      >
        <Typography variant="h5" fontWeight="600" sx={{ marginBottom: "15px" }}>
          <center>Geography Based Traffic</center>
        </Typography>
        <Box height="500px">
          <center>
            {/* <GeographyChart isDashboard={true} /> */}
          </center>
        </Box>
      </Box>
    </Box>
   </>
  );
};

export default Machineshop;
