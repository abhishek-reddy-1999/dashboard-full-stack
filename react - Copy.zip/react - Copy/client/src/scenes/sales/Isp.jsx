import React from "react";
import {
  Box,
  Button,
  IconButton,
  Input,
  Typography,
  useTheme,
  TextField,
  ButtonGroup,
} from "@mui/material";
import { tokens } from "../../theme";

import LineCharts from "../../components/LineChart";

import BarChart from "../../components/BarChart";

import PieCharts from "../../components/PieCharts";
import { useState, useEffect } from "react";
import Dashboard from "../dashboard";
import { datewise, getstack } from "../../services/api";

import { getbar } from "../../services/api";
const Isp = () => {
 
  
  return (
    <>
    <center>
        <Typography variant="h2">ISP Report</Typography>
    </center>
   <Dashboard/>
   </>
  );
};

export default Isp;
