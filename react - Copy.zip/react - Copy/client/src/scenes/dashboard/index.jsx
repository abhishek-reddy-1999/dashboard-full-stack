import React from "react";
import {
  Box,
  Button,
  IconButton,
  Input,
  Typography,
  useTheme,
  TextField,
  ButtonGroup,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  FormLabel,
} from "@mui/material";
import { tokens } from "../../theme";
import { cumulative, day, month, upto, years } from "../../services/api";
import LineCharts from "../../components/LineChart";

import BarChart from "../../components/BarChart";

import { Dropdown } from "primereact/dropdown";

import PieCharts from "../../components/PieCharts";
import { useState, useEffect } from "react";

import { datewise, getstack ,finance,partno,processs,machine} from "../../services/api";

import { getbar } from "../../services/api";
import axios from "axios";
const Dashboard = () => {
  axios.defaults.withCredentials=true
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [Bardata, setdata] = useState([]);
  const [selectedCity, setSelectedCity] = useState('');
  const [yearlist, setyearList] = useState([]);
  const[year,setyear]=useState('')
  const [datefine,setdatefin]=useState([])
  const [from,setfrom]=useState('');
  const [to,setto]=useState('');
  const [mc,setmc]=useState('');
  const [partsno,setpartno]=useState([])
  const [proces,setproces]=useState([])
  const [ma,setma]=useState([])
  function financeyear(e){
    setyear(e.target.value)
    const fin=e.target.value;
    // console.log(fin)
    const fina={
      fin
    }
    sqlbackend(fina)
  }
  const sqlbackend=async(fina)=>{
      const response=await upto(fina);
      setdatefin(response.data)
  }

  const hashf=datefine.map((e)=>{
    return e.fromdate
  })
  const hasht=datefine.map((e)=>{
    return e.todate
  })
  
  
  useEffect(() => {
    fetchUserData();
  }, []);
  const fetchUserData = async () => {
    try {
      const response_1 = await getbar();
      const response_2= await finance();
      // const response_3= await partno();
      setdata(response_1.data);
      setyearList(response_2.data)
      // setpartno(response_3.data)
      // // console.log(response.data)
    } catch (e) {
      console.log(e);
    }
  };
 function process(e){
  setto(e.target.value)
  sqlproces();
 }
 function machinemake(e){
  setmc(e.target.value)
 
  sqlmachine()
 }
function setnull(){
  setyear("")
  setSelectedCity('')
  setto("")
  setmc("")
  setfrom("")

  
}
 const sqlmachine=async()=>{
  const response=await machine();
  setma(response.data)
}
 const sqlproces=async()=>{
  const response=await processs();
  setproces(response.data)
}
 
 
 
  const getyear = async () => {
    const response = await years();
    setdata(response.data);
  };
  const yeardata = yearlist.map((element) => {
    return element.Finyear;
  });
  const months=[
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"

  ]
function findpart(e){
    setfrom(e.target.value)
    sqlparts()
  }
  const sqlparts=async()=>{
      const response=await partno();
      setpartno(response.data)
      
  }
  const partlist= partsno.map((element)=>{
    return element.Part
  })
  const proceslist= proces.map((element)=>{
    return element.PartName
  })
  const malist= ma.map((element)=>{
    return element.McName
  })
  const a=year;
  const b=from;
  const c=to;
  const d=mc;
  const e=selectedCity;
  const f=hashf[0]
  const g=hasht[0];

  const getday = async () => {
    const mana={
      month:b,
      from:f,
      to:g
    };
    const response = await day(mana);
    setdata(response.data);
  };
 
  const binddata = async (mana) => {
    var mana={
      a,b,c,d,e,e,f,g
    }
      const response = await cumulative(mana);
      setdata(response.data);
      // console.log(response.data)
  };
  const getmonth = async () => {
    var mana={
      f,g
    }
    
    const response = await month(mana);
    setdata(response.data);
  };
  return (
    <Box p="20px">
      <Box>
        <Box
          gridColumn="span 12"
          gridRow="span 4"
          backgroundColor={colors.primary[400]}
        >
          <Box sx={{ mb: "10px" }} display="flex" justifyContent="space-evenly">
            <Box>
              <FormControl>
                <FormLabel id="demo-row-radio-buttons-group-label">
                  Select
                </FormLabel>
                <RadioGroup
                  row
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="row-radio-buttons-group"
                  defaultValue="month"
                  defaultChecked={colors.redAccent}
                >
                  <FormControlLabel
                    value="day"
                    control={<Radio />}
                    label="day"
                    onClick={(e) => getday()}
                  />
                  <FormControlLabel
                    value="month"
                    control={<Radio />}
                    label="month"
                    onClick={(e) => getmonth()}
                  />
                  <FormControlLabel
                    value="year"
                    control={<Radio />}
                    label="year"
                    onClick={(e) => getyear()}
                  />
                </RadioGroup>
              </FormControl>
            </Box>
            <Box mt="25px" justifyContent="space-evenly" pr="20px">
              <Dropdown
                value={year}
                onChange={(e) => financeyear(e)}
                options={yeardata}
                placeholder="select year"
                filter
                className="w-full md:w-14rem "
              
              />&nbsp;	&nbsp;	&nbsp;
              <Dropdown
                value={from}
                onChange={(e) => findpart(e)}
                options={months}
                placeholder="Select month"
                filter
                className="w-full md:w-14rem "
        
              />&nbsp;	&nbsp;	&nbsp;
              <Dropdown
                value={to}
                onChange={(e) => process(e)}
                options={partlist}
                placeholder="Select a Partno"
                filter
                className="w-full md:w-14rem "
                
              />&nbsp;	&nbsp;	&nbsp;
              <Dropdown
                value={mc}
                onChange={(e) => machinemake(e)}
                options={proceslist}
                placeholder="Select a Process"
                filter
                className="w-full md:w-14rem "
         
              />
              &nbsp;	&nbsp;	&nbsp;
              <Dropdown
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.value)}
                options={malist}
                placeholder="Select a machine"
                filter
                className="w-full md:w-14rem "
          
              />
            </Box>
            <Box>
              <center>
                <Button
                  variant="contained"
                  color="success"
                  sx={{ mb: "10px", mr: "10px", mt: "10px" }}
                   onClick={binddata}
                >
                  Search
                </Button>
                <Button
                  variant="contained"
                  color="success"
                  sx={{ mb: "10px", mr: "10px", mt: "10px" }}
                  type="reset"
                   onClick={setnull}
                >
                  Reset
                </Button>
              </center>
            </Box>
          </Box>
        </Box>
      </Box>
      <Box
        gridColumn="span 12"
        gridRow="span 4"
        backgroundColor={colors.primary[400]}
        mt="10px"
      >
        <Box height="300px" mt="10px">
          <Typography variant="h5" fontWeight="600" mt={"-10px"}>
            <center>Sales report</center>
          </Typography>
          <BarChart data={Bardata} isDashboard={true} />
          {/* <FusionBar data={Bardata}></FusionBar> */}
        </Box>
      </Box>

      <Box
        display="grid"
        gridTemplateColumns="repeat(12, 1fr)"
        gridAutoRows="140px"
        gap="20px"
        sx={{ mt: "10px" }}
      >
        {/* ROW 1 */}
        <Box
          gridColumn="span 6"
          gridRow="span 2"
          backgroundColor={colors.primary[400]}
          p="10px"
        >
          <Typography variant="h5" fontWeight="600" margin={"5px"}>
            <center>Piecharts</center>
          </Typography>
          <PieCharts data={Bardata}></PieCharts>
        </Box>
        <Box
          gridColumn="span 6"
          gridRow="span 2"
          backgroundColor={colors.primary[400]}
          p="30px"
        >
          <center>
            <Typography variant="h5" fontWeight="600" margin={"5px"}>
              Linechart
            </Typography>
          </center>
          <LineCharts data={Bardata}></LineCharts>
        </Box>
      </Box>

      <Box
        gridColumn="span 12"
        gridRow="span 6"
        backgroundColor={colors.primary[400]}
        padding="30px"
        mt="10px"
      >
        <Typography variant="h5" fontWeight="600" sx={{ marginBottom: "15px" }}>
          <center>Geography Based Traffic</center>
        </Typography>
        <Box height="500px">
          {/* <center><GeographyChart isDashboard={true} /></center> */}
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;
