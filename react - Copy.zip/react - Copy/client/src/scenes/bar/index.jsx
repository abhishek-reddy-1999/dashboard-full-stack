import { Box } from "@mui/material";
import Header from "../../components/Header";
import BarChart from "../../components/BarChart";
import { TextField,Button } from '@mui/material'
import { useTheme } from "@mui/material";
import { tokens } from "../../theme";
import { useState } from 'react';
import { datewise,getbar} from '../../services/api';
import { useEffect } from "react";
import React from "react";

const Bar = () => {
  const [fromdate,setfromdate]=useState("");
    const[todate,settodate]=useState("");
    const [Bardata,setdata]=useState([]);




    function fromset(e){
      setfromdate(e.target.value);
    
    }
    function fromto(e){
      settodate(e.target.value);
    
    }
    function setnull(){
      setfromdate("") ;
      settodate("")
    }
    
   const dates={
    fromdate,
    todate
   }
    
    const binddata = async()=>{
     const response=await datewise(dates)
     setdata(response.data)
    }
    useEffect(() => {
      fetchUserData();
    }, []);
    const fetchUserData = async () => {
      
        try{
          const response = await getbar();
          setdata(response.data);
          // console.log(response.data)
        }catch (e){
          console.log(e)
        }
     
    };
  return (
    <>
      <Box>
          <Box sx={{mb:"10px"}}
          display="flex"
          justifyContent="space-evenly"
          >
            <TextField id="outlined-basic" label="" variant="outlined" type="date" sx={{mb:'10px',width:'200px',pr:"10px"}} onChange={(e)=>fromset(e)} value={fromdate} />
            <TextField id="outlined-basic" label="" variant="outlined" type="date" sx={{mb:"10px",width:'200px',pr:"10px"}} onChange={(e)=>fromto(e)} value={todate }  />
            <center>
             <Button variant="contained" color="success" sx={{mb:"10px", mr:"10px",mt:"10px"}} onClick={binddata} >Search</Button>
             <Button variant="contained" color="success" sx={{mb:"10px", mr:"10px",mt:"10px"}} type="reset" onClick={setnull}>Reset</Button>
            </center>
          </Box>

        </Box>
      <Box m="20px">
      <Header title="Bar Chart" subtitle="Simple Bar Chart" />
      <Box height="500px">
        <BarChart data={Bardata}/>
      </Box>
    </Box>
    
    </>
  );
};

export default Bar;
