import React from 'react'

function Person() {
  return (
    <div>person</div>
  )
}

export default Person