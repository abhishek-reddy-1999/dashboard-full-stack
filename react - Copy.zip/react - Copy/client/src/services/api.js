import axios from "axios";

const server_run = "http://192.168.24.116:4000";

export const getmap = async (user) => {
  return await axios.get(`${server_run}/map`, user);
};
export const getbar = async () => {
  return await axios.get(`${server_run}/bar`);
};
export const datewise = async (dates) => {
  return await axios.post(`${server_run}/date`,dates);
};
export const getstack = async () => {
  return await axios.get(`${server_run}/stack`);
};
export const day = async (mana) => {
  return await axios.post(`${server_run}/day`,mana);
};
export const month = async (mana) => {
  return await axios.post(`${server_run}/month`,mana);
};
export const years = async () => {
  return await axios.get(`${server_run}/year`);
};
export const finance = async () => {
  return await axios.get(`${server_run}/finace`);
};
export const upto = async (fin) => {
  return await axios.post(`${server_run}/upto`,fin);
};
export const partno = async () => {
  return await axios.get(`${server_run}/part`);
};
export const processs = async () => {
  return await axios.get(`${server_run}/proces`);
};
export const machine = async () => {
  return await axios.get(`${server_run}/machine`);
};
export const cumulative = async (mana) => {
  return await axios.post(`${server_run}/cumulative`,mana);
};

export const login = async (user) => {
  return await axios.post(`${server_run}/login`,user);
};
